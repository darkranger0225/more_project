/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : school_communication

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 19/03/2026 23:17:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for class
-- ----------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE `class`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '班级ID',
  `class_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '班级名称(如:一年级1班)',
  `grade` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '年级',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '班级描述',
  `head_teacher_id` bigint(20) NULL DEFAULT NULL COMMENT '班主任ID(教师ID)',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除:0-未删除,1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `head_teacher_id`(`head_teacher_id` ASC) USING BTREE,
  INDEX `idx_grade`(`grade` ASC) USING BTREE,
  CONSTRAINT `class_ibfk_1` FOREIGN KEY (`head_teacher_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '班级表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class
-- ----------------------------
INSERT INTO `class` VALUES (1, '二年级一班', '二年级', '二年一班，能吃能干', 3, '2026-03-14 21:36:07', '2026-03-14 21:36:07', 0);
INSERT INTO `class` VALUES (2, '一年', '一年级', '', NULL, '2026-03-14 21:36:35', '2026-03-14 21:36:40', 1);
INSERT INTO `class` VALUES (3, '八年级一班', '八年级', '', 5, '2026-03-14 21:39:51', '2026-03-14 21:39:51', 0);
INSERT INTO `class` VALUES (4, '二年级一班', '二年级', '', NULL, '2026-03-17 16:15:05', '2026-03-17 16:15:15', 1);

-- ----------------------------
-- Table structure for homework
-- ----------------------------
DROP TABLE IF EXISTS `homework`;
CREATE TABLE `homework`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '作业ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '作业标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '作业内容',
  `subject` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '科目',
  `teacher_id` bigint(20) NOT NULL COMMENT '布置教师ID',
  `class_id` bigint(20) NOT NULL COMMENT '班级ID',
  `attachment_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '附件URL',
  `deadline` datetime NOT NULL COMMENT '截止时间',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态:0-已取消,1-进行中,2-已截止',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除:0-未删除,1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_teacher_id`(`teacher_id` ASC) USING BTREE,
  INDEX `idx_class_id`(`class_id` ASC) USING BTREE,
  INDEX `idx_deadline`(`deadline` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE,
  CONSTRAINT `homework_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `homework_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `class` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '作业表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of homework
-- ----------------------------
INSERT INTO `homework` VALUES (1, '暑假作业', '所有必备内容抄一遍', '语文', 3, 1, NULL, '2026-09-01 00:00:00', 1, '2026-03-14 22:27:02', '2026-03-14 22:27:02', 0);
INSERT INTO `homework` VALUES (2, '暑假作业', '数学试卷2张', '数学', 8, 1, NULL, '2026-09-01 00:00:00', 1, '2026-03-16 00:10:53', '2026-03-16 00:10:53', 0);

-- ----------------------------
-- Table structure for homework_submit
-- ----------------------------
DROP TABLE IF EXISTS `homework_submit`;
CREATE TABLE `homework_submit`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '提交ID',
  `homework_id` bigint(20) NOT NULL COMMENT '作业ID',
  `student_id` bigint(20) NOT NULL COMMENT '学生ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '提交内容',
  `attachment_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '附件URL',
  `submit_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
  `score` decimal(5, 2) NULL DEFAULT NULL COMMENT '得分',
  `comment` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '教师评语',
  `status` tinyint(4) NULL DEFAULT 0 COMMENT '状态:0-未提交,1-已提交,2-已批改',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_homework_student`(`homework_id` ASC, `student_id` ASC) USING BTREE,
  INDEX `idx_homework_id`(`homework_id` ASC) USING BTREE,
  INDEX `idx_student_id`(`student_id` ASC) USING BTREE,
  CONSTRAINT `homework_submit_ibfk_1` FOREIGN KEY (`homework_id`) REFERENCES `homework` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `homework_submit_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '作业提交表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of homework_submit
-- ----------------------------
INSERT INTO `homework_submit` VALUES (1, 1, 1, '', '/uploads/8825065c-d794-426a-9689-093f0f48e79b.jpg', '2026-03-15 16:10:04', 90.00, '很好', 1, '2026-03-15 00:16:01', '2026-03-15 00:16:01');
INSERT INTO `homework_submit` VALUES (2, 1, 7, '', '/uploads/852df4e4-07f9-4a19-bf07-f57799563247.jpg', '2026-03-15 16:22:25', NULL, NULL, 1, '2026-03-15 16:11:38', '2026-03-15 16:11:38');
INSERT INTO `homework_submit` VALUES (3, 2, 1, '按时完成', '/uploads/a55bf7c1-5390-4c35-b1a0-08ed46db6d98.jpg', '2026-03-16 00:17:31', 80.00, '不错', 2, '2026-03-16 00:17:31', '2026-03-16 00:17:31');

-- ----------------------------
-- Table structure for leave_request
-- ----------------------------
DROP TABLE IF EXISTS `leave_request`;
CREATE TABLE `leave_request`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '请假ID',
  `student_id` bigint(20) NOT NULL COMMENT '学生ID',
  `parent_id` bigint(20) NOT NULL COMMENT '申请人(家长)ID',
  `leave_type` enum('SICK','PERSONAL','OTHER') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '请假类型:病假/事假/其他',
  `start_date` date NOT NULL COMMENT '开始日期',
  `end_date` date NOT NULL COMMENT '结束日期',
  `days` int(11) NOT NULL COMMENT '请假天数',
  `reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '请假原因',
  `attachment_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '附件(如病假条)',
  `status` enum('PENDING','APPROVED','REJECTED') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'PENDING' COMMENT '状态:待审批/已通过/已拒绝',
  `approver_id` bigint(20) NULL DEFAULT NULL COMMENT '审批人ID',
  `approve_time` datetime NULL DEFAULT NULL COMMENT '审批时间',
  `approve_remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '审批备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除:0-未删除,1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `approver_id`(`approver_id` ASC) USING BTREE,
  INDEX `idx_student_id`(`student_id` ASC) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE,
  CONSTRAINT `leave_request_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `leave_request_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `leave_request_ibfk_3` FOREIGN KEY (`approver_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '请假申请表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of leave_request
-- ----------------------------
INSERT INTO `leave_request` VALUES (1, 1, 2, 'SICK', '2026-03-14', '2026-03-14', 1, '感冒', NULL, 'REJECTED', 3, '2026-03-15 01:16:06', '拒绝', '2026-03-14 23:57:09', '2026-03-15 01:32:50', 0);
INSERT INTO `leave_request` VALUES (2, 1, 2, 'SICK', '2026-03-15', '2026-03-16', 2, '感冒', NULL, 'APPROVED', 8, '2026-03-16 01:07:45', '批准', '2026-03-15 00:04:08', '2026-03-15 01:33:03', 0);
INSERT INTO `leave_request` VALUES (3, 6, 2, 'PERSONAL', '2026-03-15', '2026-03-16', 2, '走亲访友', NULL, 'PENDING', NULL, NULL, NULL, '2026-03-15 00:04:56', '2026-03-15 00:04:56', 0);
INSERT INTO `leave_request` VALUES (4, 6, 2, 'PERSONAL', '2026-03-17', '2026-03-17', 1, '参加校外考试', NULL, 'PENDING', NULL, NULL, NULL, '2026-03-17 14:50:07', '2026-03-17 14:50:07', 0);

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '通知ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '通知标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '通知内容',
  `publisher_id` bigint(20) NOT NULL COMMENT '发布人ID',
  `target_type` enum('ALL','CLASS','PARENT') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '目标类型:全部/班级/家长',
  `target_ids` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '目标ID列表(逗号分隔,如班级ID或家长ID)',
  `priority` tinyint(4) NULL DEFAULT 0 COMMENT '优先级:0-普通,1-重要,2-紧急',
  `read_count` int(11) NULL DEFAULT 0 COMMENT '已读人数',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态:0-草稿,1-已发布,2-已撤回',
  `publish_time` datetime NULL DEFAULT NULL COMMENT '发布时间',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除:0-未删除,1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_publisher`(`publisher_id` ASC) USING BTREE,
  INDEX `idx_target_type`(`target_type` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE,
  CONSTRAINT `notice_ibfk_1` FOREIGN KEY (`publisher_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '通知表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, '月考通知', '月考临近，请大家利用假期多做准备！', 3, 'CLASS', '1', 0, 2, 1, '2026-03-16 01:37:10', '2026-03-16 01:37:10', '2026-03-16 01:42:27', 0);

-- ----------------------------
-- Table structure for notice_read
-- ----------------------------
DROP TABLE IF EXISTS `notice_read`;
CREATE TABLE `notice_read`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `notice_id` bigint(20) NOT NULL COMMENT '通知ID',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `read_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '阅读时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_notice_user`(`notice_id` ASC, `user_id` ASC) USING BTREE,
  INDEX `idx_notice_id`(`notice_id` ASC) USING BTREE,
  INDEX `idx_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `notice_read_ibfk_1` FOREIGN KEY (`notice_id`) REFERENCES `notice` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `notice_read_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '通知已读记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notice_read
-- ----------------------------
INSERT INTO `notice_read` VALUES (1, 1, 3, '2026-03-16 01:40:59');
INSERT INTO `notice_read` VALUES (2, 1, 2, '2026-03-16 01:42:27');

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '成绩ID',
  `student_id` bigint(20) NOT NULL COMMENT '学生ID',
  `exam_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '考试名称',
  `subject` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '科目',
  `score` decimal(5, 2) NOT NULL COMMENT '分数',
  `full_score` decimal(5, 2) NULL DEFAULT 100.00 COMMENT '满分',
  `teacher_id` bigint(20) NOT NULL COMMENT '录入教师ID',
  `exam_date` date NOT NULL COMMENT '考试日期',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除:0-未删除,1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `teacher_id`(`teacher_id` ASC) USING BTREE,
  INDEX `idx_student_id`(`student_id` ASC) USING BTREE,
  INDEX `idx_exam_name`(`exam_name` ASC) USING BTREE,
  INDEX `idx_exam_date`(`exam_date` ASC) USING BTREE,
  CONSTRAINT `score_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `score_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '成绩表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES (1, 1, '月考', '语文', 85.00, 100.00, 3, '2026-02-12', '2026-03-14 23:17:01', '2026-03-14 23:17:01', 0);
INSERT INTO `score` VALUES (2, 7, '月考', '语文', 68.00, 100.00, 3, '2026-02-12', '2026-03-14 23:17:01', '2026-03-14 23:17:01', 0);
INSERT INTO `score` VALUES (3, 1, '月考', '数学', 89.00, 100.00, 8, '2026-02-12', '2026-03-16 00:09:36', '2026-03-16 00:09:36', 0);
INSERT INTO `score` VALUES (4, 7, '月考', '数学', 56.00, 100.00, 8, '2026-02-12', '2026-03-16 00:09:36', '2026-03-16 00:09:36', 0);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '学生ID',
  `student_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '学生姓名',
  `student_no` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '学号',
  `class_id` bigint(20) NOT NULL COMMENT '班级ID',
  `parent_id` bigint(20) NOT NULL COMMENT '家长ID',
  `gender` tinyint(4) NULL DEFAULT NULL COMMENT '性别:0-女,1-男',
  `birth_date` date NULL DEFAULT NULL COMMENT '出生日期',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除:0-未删除,1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `student_no`(`student_no` ASC) USING BTREE,
  INDEX `idx_class_id`(`class_id` ASC) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE,
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `student_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '学生表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1, '赵宇', '20180201', 1, 2, 1, '2018-03-14', '2026-03-14 21:55:13', '2026-03-14 21:55:13', 0);
INSERT INTO `student` VALUES (2, '孟佳佳', '20120801', 3, 6, 0, '2012-02-14', '2026-03-14 21:59:43', '2026-03-14 21:59:43', 0);
INSERT INTO `student` VALUES (6, '赵嘉欣', '20128810', 3, 2, 0, '2012-05-14', '2026-03-14 22:58:43', '2026-03-14 23:00:24', 0);
INSERT INTO `student` VALUES (7, '孟梁', '202603143183', 1, 6, 1, '2018-01-16', '2026-03-14 23:10:06', '2026-03-14 23:10:06', 0);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码(BCrypt加密)',
  `real_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '真实姓名',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像URL',
  `role` enum('PARENT','TEACHER','ADMIN') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '角色:家长/教师/管理员',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态:0-禁用,1-启用',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除:0-未删除,1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  INDEX `idx_role`(`role` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', '$2a$10$ZMeLTBcXaBSOb6K2WQx.2uL8MOVR5SoXEozSRERMmAotHZBuukv/.', '系统管理员', '13800138000', NULL, 'ADMIN', 1, '2026-03-13 20:37:44', '2026-03-13 20:37:44', 0);
INSERT INTO `sys_user` VALUES (2, 'Zhao', '$2a$10$IG/0TSmr1lbgvp82L2ScX.rpnJoQyR6opgfl1lkq4R2SS0zr2u/1e', '赵明明', '13000120011', NULL, 'PARENT', 1, '2026-03-13 21:48:31', '2026-03-14 23:26:02', 0);
INSERT INTO `sys_user` VALUES (3, '张老师', '$2a$10$DwpMGAwrfOHG2TPWvurnBO0HixwK2hR3n9yfD7OECzOv66aoQmSv.', '张得草', '13100003495', NULL, 'TEACHER', 1, '2026-03-14 18:05:57', '2026-03-17 00:34:48', 0);
INSERT INTO `sys_user` VALUES (4, 'user1', '$2a$10$b98/iLVUROZV6lzwiWIPSORYh3CEO6.L1fMI70yH/.THymYw0a1.m', 'user1', '132312312', NULL, 'PARENT', 1, '2026-03-14 18:56:49', '2026-03-15 23:50:24', 1);
INSERT INTO `sys_user` VALUES (5, '飞扬老师', '$2a$10$5y3B79Ml2ect3kDAKKP7TenAH.p81FFFzyNXBX9eBf1K7BLtOQsoa', '李飞扬', '13100023123', NULL, 'TEACHER', 1, '2026-03-14 21:37:58', '2026-03-14 21:37:58', 0);
INSERT INTO `sys_user` VALUES (6, 'Meng', '$2a$10$wTB2nq7VtdkgUYGUKYG71.DddiSN7/wb7SBz4tcBj2OucMVe6EP4C', '孟雨菲', '13023124134', NULL, 'PARENT', 1, '2026-03-14 21:57:31', '2026-03-14 21:57:31', 0);
INSERT INTO `sys_user` VALUES (7, '123', '$2a$10$SnLlyHN2PRkxGGsk99MuI..BCUtl/BgBBPSCd22a24ChGzyQyhcwi', '213', NULL, NULL, 'PARENT', 1, '2026-03-14 23:06:42', '2026-03-14 23:06:52', 1);
INSERT INTO `sys_user` VALUES (8, '李老师', '$2a$10$ugygroFPqeKUqt1xHNk3nusmNCjg01bZUTddOV/5xoG442x6S5xPK', '李自成', '13023984572', NULL, 'TEACHER', 1, '2026-03-15 23:49:52', '2026-03-15 23:49:52', 0);

-- ----------------------------
-- Table structure for teacher_class
-- ----------------------------
DROP TABLE IF EXISTS `teacher_class`;
CREATE TABLE `teacher_class`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `teacher_id` bigint(20) NOT NULL COMMENT '教师ID',
  `class_id` bigint(20) NOT NULL COMMENT '班级ID',
  `subject` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '任教科目',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_teacher_class`(`teacher_id` ASC, `class_id` ASC) USING BTREE,
  INDEX `idx_teacher_id`(`teacher_id` ASC) USING BTREE,
  INDEX `idx_class_id`(`class_id` ASC) USING BTREE,
  CONSTRAINT `teacher_class_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `teacher_class_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `class` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '教师班级关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacher_class
-- ----------------------------
INSERT INTO `teacher_class` VALUES (4, 8, 1, '数学', '2026-03-16 00:54:09');

SET FOREIGN_KEY_CHECKS = 1;
